package com.music.darkmusicplayer.ui.songs;

import com.music.darkmusicplayer.ui.base.MvpPresenter;

public interface ISongListPresenter extends MvpPresenter {

    void loadLocalMusic();

}
