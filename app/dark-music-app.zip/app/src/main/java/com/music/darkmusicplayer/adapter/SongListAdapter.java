package com.music.darkmusicplayer.adapter;

import android.content.ContentUris;
import android.content.Context;
import android.net.Uri;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.music.darkmusicplayer.EventBus;
import com.music.darkmusicplayer.MyApplication;
import com.music.darkmusicplayer.R;

import com.music.darkmusicplayer.data.model.Song;


import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;

public class SongListAdapter extends RecyclerView.Adapter<SongListAdapter.SongListViewHolder> {
    private List<Song> mSongList;
    private Context mContext;
    private static final String TAG = "SongListAdapter";


    public SongListAdapter(List<Song> mSongList, Context mContext) {
        this.mSongList = mSongList;
        this.mContext = mContext;
    }

    @NonNull
    @Override
    public SongListViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.row_song_list, parent, false);
        return new SongListViewHolder(itemView);
    }


    public void setmSongList(List<Song> songList) {
        this.mSongList = songList;
        Log.d(TAG, "setmSongList: "+mSongList.size());
        notifyDataSetChanged();
    }



    @Override
    public void onBindViewHolder(@NonNull SongListViewHolder holder, int position) {
        Song song = mSongList.get(position);
        holder.mSongNameItemText.setText(song.getDisplayName());
        holder.mSongArtistItemText.setText(song.getArtist());
        Uri sArtworkUri = Uri
                .parse("content://media/external/audio/albumart");

        Uri abumArturi = ContentUris.withAppendedId(sArtworkUri, song.getAlbumID());

        Glide.with(mContext)
                .load(abumArturi.toString())
                .placeholder(R.drawable.ic_music_image)
                .into(holder.mSongAlbumArtItemImage);

        Log.d(TAG, "onBindViewHolder: " + abumArturi.getPath());
        Log.d(TAG, "onBindViewHolder: "+holder.mSongArtistItemText.getText());

//        if(position==0){
////            holder.mSongAnimVisualizer.setVisibility(View.VISIBLE);
////
////            holder.mSongAnimVisualizer.setColor(mContext.getResources().getColor(R.color.colorLightBlue));
//            PlayerService.isPlaying=false;
//            ((MyApplication)mContext.getApplicationContext())
//                    .bus()
//                    .send(new EventBus.SendSongList(position,mSongList));
//        }

        holder.itemView.setOnClickListener(v -> {

//            holder.mSongAnimVisualizer.setVisibility(View.VISIBLE);
//
//            holder.mSongAnimVisualizer.setColor(mContext.getResources().getColor(R.color.colorLightBlue));
            ((MyApplication)mContext.getApplicationContext())
                    .bus()
                    .send(new EventBus.SendSongList(position,mSongList));


        });


    }


    @Override
    public int getItemCount() {
        if (mSongList != null) {
            return mSongList.size();
        }
        return 0;
    }


    public class SongListViewHolder extends RecyclerView.ViewHolder {
        //
        @BindView(R.id.name_songItem_text)
        TextView mSongNameItemText;

        @BindView(R.id.artist_songItem_text)
        TextView mSongArtistItemText;

        @BindView(R.id.icon_songItem_image)
        ImageView mSongAlbumArtItemImage;


        public SongListViewHolder(@NonNull View itemView) {
            super(itemView);
            ButterKnife.bind(this, itemView);
        }
    }
}
