package com.music.darkmusicplayer.ui.songs;

import android.content.Context;
import android.os.Bundle;

import android.os.FileUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.Nullable;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.music.darkmusicplayer.R;
import com.music.darkmusicplayer.adapter.SongListAdapter;
import com.music.darkmusicplayer.data.model.Song;
import com.music.darkmusicplayer.ui.base.BaseFragment;

import java.util.ArrayList;
import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;


public class SongFragments extends BaseFragment implements ISongsListView {


    @BindView(R.id.recycler_view_songList)
    RecyclerView mRecyclerViewSong;

    private static final String TAG = "SongFragments";

    private SongListAdapter mSongListAdapter;
    private static final String FOLDER_SONG= "foldersong";

    private List<Song> mSongList;

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_songs, container, false);
    }

    private void setDefaults() {
        mRecyclerViewSong.setLayoutManager(new LinearLayoutManager(getActivity()));
        mSongListAdapter = new SongListAdapter(null, getActivity());
        mRecyclerViewSong.setAdapter(mSongListAdapter);
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        ButterKnife.bind(this, view);
        setDefaults();
        new SongsListPresenter(this).loadLocalMusic();

    }

    @Override
    public void onDetach() {
        super.onDetach();
    }


    @Override
    public void emptyView(boolean visible) {

    }

    @Override
    public void handleError(Throwable error) {

    }

    @Override
    public void onLocalMusicLoaded(List<Song> songs) {
        Log.d(TAG, "onLocalMusicLoaded: "+songs.size());
        mSongListAdapter.setmSongList(songs);
    }


}
