package com.music.darkmusicplayer;
public enum PlaybackStatus {
    PLAYING,
    PAUSED
}
