package com.music.darkmusicplayer.ui.folder;

public interface IFolderPresenter  {

    void LoadFolder();

}
