package com.music.darkmusicplayer;

public class Constants {

    public static final String  PREF_NAME="dark-music";
    public static final String  AUDIO_INDEX="audioIndex";
    public static final String  AUDIO_LIST="audioList";
}
