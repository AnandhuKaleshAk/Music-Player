package com.music.darkmusicplayer.ui.base;

public interface MvpPresenter {


}
