package com.music.darkmusicplayer.ui.folder;

import android.content.Context;
import android.os.Bundle;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.Nullable;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.music.darkmusicplayer.EventBus;
import com.music.darkmusicplayer.MyApplication;
import com.music.darkmusicplayer.R;
import com.music.darkmusicplayer.adapter.FolderAdapter;
import com.music.darkmusicplayer.data.model.Folder;
import com.music.darkmusicplayer.data.model.Song;
import com.music.darkmusicplayer.ui.albumdetails.AlbumDetailFragment;
import com.music.darkmusicplayer.ui.base.BaseFragment;
import com.music.darkmusicplayer.ui.songs.SongFragments;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import butterknife.BindView;
import butterknife.ButterKnife;

public class FolderFragments extends BaseFragment implements IFolderView, FolderAdapter.OnFolderItemClickedListener {
    // TODO: Rename parameter arguments, choose names that match


    @BindView(R.id.recycler_view_folder)
    RecyclerView mRecyclerViewFolder;

    private List<Folder> mFolderList;

    private FragmentManager mFragmentManager;

    private FolderAdapter mFolderAdapter;
    private static final String TAG = "FolderFragments";
    private static final String FOLDER_SONG= "foldersong";
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_folder, container, false);
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        ButterKnife.bind(this, view);
        setUP();
        new FolderPresenter(this).LoadFolder();
    }


    private void setUP() {
         mFragmentManager=getFragmentManager();
        mFolderList = new ArrayList<>();
        mRecyclerViewFolder.setLayoutManager(new LinearLayoutManager(getActivity()));
        mFolderAdapter = new FolderAdapter(mFolderList, getActivity());
        mRecyclerViewFolder.setAdapter(mFolderAdapter);
        mFolderAdapter.setmOnFolderItemClickedListener(this);
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);

    }

    @Override
    public void onDetach() {
        super.onDetach();
    }


    @Override
    public void onFolderLoaded(List<Folder> folderList) {
        Log.d(TAG, "onFolderLoaded: " + folderList.get(1).getNoOfSongs());
        mFolderAdapter.setFolderList(folderList);
    }

    @Override
    public void onFolderClicked(int position, List<Song> mSongList) {

        Bundle arguments = new Bundle();
        arguments.putSerializable(FOLDER_SONG, (Serializable) mSongList);
        BaseFragment mSongFragment = new FolderSongFragment();
        mSongFragment.setArguments(arguments);
        String backToStackName = getClass().getName();

        FragmentTransaction fragmentTransaction = mFragmentManager.beginTransaction()/*.addToBackStack("")*/;
        fragmentTransaction.addToBackStack(backToStackName);
        fragmentTransaction.replace(R.id.container_folder, mSongFragment);
        fragmentTransaction.commit();

    }

}
