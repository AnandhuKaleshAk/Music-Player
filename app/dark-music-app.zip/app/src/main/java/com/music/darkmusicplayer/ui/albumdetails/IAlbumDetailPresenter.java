package com.music.darkmusicplayer.ui.albumdetails;

public interface IAlbumDetailPresenter {

    void loadAlbumSongs(String albumId);
}
