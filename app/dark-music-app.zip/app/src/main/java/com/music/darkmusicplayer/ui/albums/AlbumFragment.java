package com.music.darkmusicplayer.ui.albums;

import android.content.Context;

import android.content.Intent;
import android.os.Bundle;

import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;


import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.music.darkmusicplayer.R;
import com.music.darkmusicplayer.adapter.AlbumListAdapter;
import com.music.darkmusicplayer.data.model.Album;
import com.music.darkmusicplayer.ui.albumdetails.AlbumDetailActivity;
import com.music.darkmusicplayer.ui.albumdetails.AlbumDetailFragment;
import com.music.darkmusicplayer.ui.base.BaseFragment;

import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;

public class AlbumFragment extends BaseFragment implements IAlbumView, AlbumListAdapter.OnAlbumSelectedListener {


    @BindView(R.id.recycler_view_album)
    RecyclerView mRecyclerViewAlbum;

    private AlbumListAdapter mAlbumListAdapter;

    private FragmentManager mFragmentManager;
    private static final String TAG = "AlbumFragment";
    private static final String ALBUM_ID = "albumID";


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_album, container, false);

    }

    private void setUp() {
        mFragmentManager = getFragmentManager();
        mAlbumListAdapter = new AlbumListAdapter(null, getActivity());
        mRecyclerViewAlbum.setLayoutManager(new GridLayoutManager(getActivity(), 2));
        mRecyclerViewAlbum.setAdapter(mAlbumListAdapter);
        mAlbumListAdapter.setOnAlbumSelectedListener(this);
    }


    @Override
    public void onAttach(Context context) {
        super.onAttach(context);

    }

    @Override
    public void onDetach() {
        super.onDetach();
    }


    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        ButterKnife.bind(this, view);
        setUp();
        new AlbumListPresenter(this).onLoadAlbum();
    }


    @Override
    public void onAlbumLoaded(List<Album> songs) {
        mAlbumListAdapter.setmAlbumList(songs);
    }


    @Override
    public void onAlbumSelected(int albumid) {
        Log.d(TAG, "onAlbumSelected: " + albumid);
        Bundle arguments = new Bundle();
        arguments.putInt(ALBUM_ID,albumid);
        BaseFragment mAlbumDetailFragment = new AlbumDetailFragment();
        mAlbumDetailFragment.setArguments(arguments);
        String backToStackName = mAlbumDetailFragment.getClass().getName();

        FragmentTransaction fragmentTransaction = mFragmentManager.beginTransaction()/*.addToBackStack("")*/;
        fragmentTransaction.addToBackStack(backToStackName);
        fragmentTransaction.replace(R.id.container_album, mAlbumDetailFragment);
        fragmentTransaction.commit();
    }
}
