package com.music.darkmusicplayer.ui.base;

public interface DialogMvpView {

    void dismissDialog(String tag);

}
