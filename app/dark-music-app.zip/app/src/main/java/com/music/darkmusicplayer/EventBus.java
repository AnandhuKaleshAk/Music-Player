package com.music.darkmusicplayer;

import com.music.darkmusicplayer.data.model.Song;

import java.util.List;

public class EventBus {

    public static class SendSongList {
        private int mPosition;
        private List<Song> mSongList;

        public SendSongList(int mPosition, List<Song> mSongList) {
            this.mPosition = mPosition;
            this.mSongList = mSongList;
        }

        public int getmPosition() {
            return mPosition;
        }

        public List<Song> getmSongList() {
            return mSongList;
        }


    }



    public static class SendSongService {
        private int mPosition;
        private List<Song> mSongList;

        public SendSongService(int mPosition, List<Song> mSongList) {
            this.mPosition = mPosition;
            this.mSongList = mSongList;
        }

        public int getmPosition() {
            return mPosition;
        }

        public List<Song> getmSongList() {
            return mSongList;
        }
    }

    public static class hideUIActivity{
        private Boolean status;

        public hideUIActivity(Boolean status) {
            this.status = status;
        }

        public Boolean getStatus() {
            return status;
        }
    }

    public static class LoadFavourites{
        private Boolean status;

        public LoadFavourites(Boolean status) {
            this.status = status;
        }

        public void setStatus(Boolean status) {
            this.status = status;
        }
    }

    public static class LoadPlayList{

        private Boolean status;

        public LoadPlayList(Boolean status) {
            this.status = status;
        }

        public void setStatus(Boolean status) {
            this.status = status;
        }
    }

    public static class PlayPause{
        private int mPosition;

        public PlayPause(int mPosition) {
            this.mPosition = mPosition;
        }

        public int getmPosition() {
            return mPosition;
        }

        public void setmPosition(int mPosition) {
            this.mPosition = mPosition;
        }
    }



    public static class sendAddedSongs{
        private int mPosition;
        private List<Song> mSong;

        public sendAddedSongs(int mPosition, List<Song> mSong) {
            this.mPosition = mPosition;
            this.mSong = mSong;
        }

        public int getmPosition() {
            return mPosition;
        }
        public List<Song> getmSong() {
            return mSong;
        }
    }


    public static class sendProgress{
        private int duration;
        private int  currentDuration;
        private PlaybackStatus mPlaybackStatus;


        public sendProgress(int duration, int currentDuration, PlaybackStatus mPlaybackStatus) {
            this.duration = duration;
            this.currentDuration = currentDuration;
            this.mPlaybackStatus = mPlaybackStatus;
        }

        public int getDuration() {
            return duration;
        }

        public void setDuration(int duration) {
            this.duration = duration;
        }

        public int getCurrentDuration() {
            return currentDuration;
        }

        public void setCurrentDuration(int currentDuration) {
            this.currentDuration = currentDuration;
        }

        public PlaybackStatus getmPlaybackStatus() {
            return mPlaybackStatus;
        }

        public void setmPlaybackStatus(PlaybackStatus mPlaybackStatus) {
            this.mPlaybackStatus = mPlaybackStatus;
        }
    }
}
