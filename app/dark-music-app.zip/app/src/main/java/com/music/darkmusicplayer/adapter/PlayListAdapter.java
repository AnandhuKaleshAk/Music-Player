package com.music.darkmusicplayer.adapter;

import android.content.ContentUris;
import android.content.Context;
import android.net.Uri;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.music.darkmusicplayer.R;
import com.music.darkmusicplayer.data.model.PlayList;
import com.music.darkmusicplayer.data.model.Song;

import java.util.ArrayList;

import butterknife.BindView;
import butterknife.ButterKnife;

public class PlayListAdapter extends RecyclerView.Adapter<PlayListAdapter.PlayListViewHolder> {

    private ArrayList<PlayList> mPlayLists;

    private Context mContext;


    public PlayListAdapter(ArrayList<PlayList> mPlayLists, Context mContext) {
        this.mPlayLists = mPlayLists;
        this.mContext = mContext;
    }

    @NonNull
    @Override
    public PlayListViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.row_playlist_list, parent, false);
        return new PlayListViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull PlayListViewHolder holder, int position) {
        String noOfsongs=mPlayLists.get(position).getNoOfSongs()+" "+mContext.getResources().getString(R.string.no_of_songs);
        holder.mNamePlayListItemText.setText(mPlayLists.get(position).getPlayListName());
        holder.mNoSongsPlayListItemText.setText(noOfsongs);
        if(position==0){
            holder.mIconPlayListItemImageView.setImageResource(mPlayLists.get(position).getImageId());
        }



    }

    @Override
    public int getItemCount() {
        if (mPlayLists != null) {
            return mPlayLists.size();
        }
        return 0;
    }

    public class PlayListViewHolder extends RecyclerView.ViewHolder{

        //
        @BindView(R.id.name_playListItem_text)
        TextView mNamePlayListItemText;

        @BindView(R.id.noSongs_playListItem_text)
        TextView mNoSongsPlayListItemText;

        @BindView(R.id.icon_playListItem_image)
        ImageView mIconPlayListItemImageView;


        public PlayListViewHolder(@NonNull View itemView) {
            super(itemView);
            ButterKnife.bind(this,itemView);
        }
    }
}
