package com.music.darkmusicplayer.utils;

import android.content.ContentResolver;
import android.database.Cursor;
import android.media.MediaMetadataRetriever;
import android.net.Uri;
import android.provider.MediaStore;
import android.text.TextUtils;
import android.util.Log;

import com.music.darkmusicplayer.MyApplication;
import com.music.darkmusicplayer.data.model.Folder;
import com.music.darkmusicplayer.data.model.Song;

import java.io.File;
import java.io.FileFilter;
import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;

public class FileUtils {

    private static final String UNKNOWN = "unknown";
    private static final String TAG = "FileUtils";


    public static Folder folderFromDir(File dir) {
        Folder folder = new Folder();

        List<Song> songList = musicFiles(dir);
        folder.setName(dir.getName());
        folder.setPath(dir.getAbsolutePath());
        folder.setSongs((ArrayList<Song>) songList);
        folder.setNoOfSongs(songList.size());
        return folder;
    }

    public static HashSet<File> foldersFromSdCard(File dir, HashSet<File> mFileList) {

        File[] sdCardfiles = dir.listFiles();
        if (sdCardfiles != null) {
            for (File file : sdCardfiles) {
                if (file != null) {
                    if (file.isDirectory()) {
                        if(!isAndroidDirectory(file)) {
                            if(!isCacheDirectory(file)){
                                foldersFromSdCard(file, mFileList);
                            }
                        }
                    } else {
                        if (isMusic(file)) {
                                Log.d(TAG, "foldersFromSdCard: " + file.getParent());
                                mFileList.add(file.getParentFile());
                        }
                    }

                }
            }
        }


        return mFileList;
    }



    public static List<Song> musicFiles(File dir) {
        List<Song> songs = new ArrayList<>();


        if (dir != null && dir.isDirectory()) {

            ArrayList<File> fileList = new ArrayList<>();
            final File[] files = dir.listFiles(new FileFilter() {
                @Override
                public boolean accept(File item) {
                    if (isMusic(item)) {

                        fileList.add(item);
                    }
                    return item.isFile() && isMusic(item);
                }
            });


            for (File file : fileList) {
                Cursor songCursor=null;
                try {
                    Uri uri=Uri.fromFile(file);
                    String path = new File (new URI(uri.toString())).getAbsolutePath();
                    Log.d(TAG, "musicFiles: "+path);
                    songCursor = (MyApplication.getAppContext()).getContentResolver().query(
                            MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,
                            new String[] {
                                    MediaStore.Audio.Media.DATA, // the real path
                                    MediaStore.Audio.Media.TITLE,
                                    MediaStore.Audio.Media.DISPLAY_NAME,
                                    MediaStore.Audio.Media.MIME_TYPE,
                                    MediaStore.Audio.Media.ARTIST,
                                    MediaStore.Audio.Media.ALBUM,
                                    MediaStore.Audio.Media.IS_RINGTONE,
                                    MediaStore.Audio.Media.IS_MUSIC,
                                    MediaStore.Audio.Media.IS_NOTIFICATION,
                                    MediaStore.Audio.Media.DURATION,
                                    MediaStore.Audio.Media.SIZE,
                                    MediaStore.Audio.Media.ALBUM_ID,
                                    MediaStore.Audio.Media.DATE_ADDED
                            },
                            MediaStore.Audio.Media.DATA + " = ?",
                            new String[] {
                                   path
                            },
                            "");
                } catch (URISyntaxException e) {
                    e.printStackTrace();
                }
                songCursor.moveToFirst();
                Song song = cursorToMusic(songCursor);
                if (song != null) {
                    songs.add(song);
                }

            }
            if (songs.size() > 1) {
                Collections.sort(songs, (left, right) -> left.getTitle().compareTo(right.getTitle()));

            }
        }
        return songs;
    }



    public static boolean isAndroidDirectory(File file) {
        return file.getName().matches("Android");
    }

    public static boolean isCacheDirectory(File file) {
        Log.d(TAG, "isCacheDirectory: "+file.getName());
        return file.getName().startsWith(".");

    }
    public static boolean isMusic(File file) {
        final String REGEX = "(.*/)*.+\\.(mp3||wav|)$";
        return file.getName().matches(REGEX);
    }



    public  static  Song cursorToMusic(Cursor cursor) {
        String realPath = cursor.getString(cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.DATA));
        File songFile = new File(realPath);
        Song song;
        song = new Song();
        song.setTitle(cursor.getString(cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE)));
        String displayName = cursor.getString(cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.DISPLAY_NAME));
        if (displayName.endsWith(".mp3")) {
            displayName = displayName.substring(0, displayName.length() - 4);
        }
        song.setDisplayName(displayName);
        song.setArtist(cursor.getString(cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST)));
        song.setAlbum(cursor.getString(cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM)));
        song.setPath(cursor.getString(cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.DATA)));
        song.setDuration(cursor.getInt(cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.DURATION)));
        song.setSize(cursor.getInt(cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.SIZE)));
        song.setAlbumID(cursor.getInt(cursor.getColumnIndexOrThrow(MediaStore.Audio.Albums.ALBUM_ID)));
        song.setAddedTime(cursor.getInt(cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.DATE_ADDED)));
        song.setPlayedTime(0);

        return song;
    }


}
