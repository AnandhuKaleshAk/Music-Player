package com.music.darkmusicplayer.ui.albumdetails;

import android.content.ContentUris;
import android.content.Context;
import android.net.Uri;
import android.os.Bundle;

import com.bumptech.glide.Glide;
import com.google.android.material.appbar.AppBarLayout;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.util.DisplayMetrics;
import android.util.Log;
import android.view.Display;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import com.music.darkmusicplayer.R;
import com.music.darkmusicplayer.adapter.SongListAdapter;
import com.music.darkmusicplayer.data.model.Song;
import com.music.darkmusicplayer.ui.base.BaseActivity;

import java.util.ArrayList;
import java.util.List;

import butterknife.BindAnim;
import butterknife.BindView;
import butterknife.ButterKnife;

public class AlbumDetailActivity extends BaseActivity implements IAlbumDetailView{

    @BindView(R.id.app_bar)
    AppBarLayout mAppBarLayout;

    @BindView(R.id.toolbar)
    Toolbar mToolbarAlbum;


    @BindView(R.id.recyclerview_album_detail)
    RecyclerView mRecyclerViewSongAlbum;

    @BindView(R.id.image_abumdetail_back)
    ImageView mBackAlbumDetailImageView;


    @BindView(R.id.image_albumdetail_cover)
    ImageView mCoverAlbumDetailImageView;



    private String albumIntentId="albumId";


    private List<Song> mSongList=new ArrayList<>();
    private SongListAdapter mSongListAdapter;


    public  int albumId;

    private static final String TAG = "AlbumDetailActivity";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_album_detail);
        ButterKnife.bind(this);
        setToolbarDimension();
        init();

    }


    private  void init(){
        setSupportActionBar(mToolbarAlbum);
        mBackAlbumDetailImageView.setOnClickListener(v -> {
                finish();
        });
        mRecyclerViewSongAlbum.setLayoutManager(new LinearLayoutManager(this));
        mSongListAdapter = new SongListAdapter(mSongList, this);
        mRecyclerViewSongAlbum.setAdapter(mSongListAdapter);
        albumId=getIntent().getIntExtra(albumIntentId,0);

        Uri sArtworkUri = Uri
                .parse("content://media/external/audio/albumart");

        Uri abumArturi = ContentUris.withAppendedId(sArtworkUri, albumId);
        Glide.with(this)
                .load(abumArturi.toString())
                .into(mCoverAlbumDetailImageView);
        new AlbumDetailPresenter(this).loadAlbumSongs(String.valueOf(albumId));
    }

    public void setToolbarDimension(){

        Display display = getWindowManager().getDefaultDisplay();DisplayMetrics outMetrics = new DisplayMetrics();
        display.getMetrics(outMetrics);

        ViewGroup.LayoutParams params = mAppBarLayout.getLayoutParams();
        int height =(outMetrics.heightPixels / 3);
        params.height = height;
        mAppBarLayout.setLayoutParams(params);
    }


    @Override
    public void onSongsLoaded(List<Song> songs) {
        mSongListAdapter.setmSongList(songs);
        mToolbarAlbum.setTitle("");
        if(songs.get(0).getAlbum().equals("")){
          //  mToolbarAlbum.setTitle(getResources().getString(R.string.unknown));

        }
        else {
         //   mToolbarAlbum.setTitle(songs.get(0).getAlbum());

        }
    }

    @Override
    public Context getContext() {
        return null;
    }

}
