package com.music.darkmusicplayer.ui.folder;

import com.music.darkmusicplayer.data.source.AppRepository;

import io.reactivex.Scheduler;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.disposables.Disposable;
import io.reactivex.schedulers.Schedulers;

public class FolderPresenter implements IFolderPresenter {

    private IFolderView mIFolderView;

    private AppRepository mAppRepository;

    public FolderPresenter(IFolderView mIFolderView) {
        this.mIFolderView = mIFolderView;
        mAppRepository=new AppRepository(mIFolderView.getContext());

    }


    @Override
    public void LoadFolder() {
        mIFolderView.showLoading();
        Disposable mFolderDisposible=mAppRepository.getFolders()
                   .observeOn(AndroidSchedulers.mainThread())
                   .subscribeOn(Schedulers.io())
                   .subscribe(
                           result->{
                               mIFolderView.hideLoading();
                               mIFolderView.onFolderLoaded(result);
                           }
                   );
        mIFolderView.addDisposible(mFolderDisposible);
    }
}
