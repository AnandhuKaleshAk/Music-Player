package com.music.darkmusicplayer.utils;

import android.net.Uri;

public class Constants {

    final public static Uri sArtworkUri = Uri
            .parse("content://media/external/audio/albumart");
}
