package com.music.darkmusicplayer.ui.albums;

import com.music.darkmusicplayer.ui.base.MvpPresenter;

public interface IAlbumListPresenter extends MvpPresenter {

    void onLoadAlbum();

}
